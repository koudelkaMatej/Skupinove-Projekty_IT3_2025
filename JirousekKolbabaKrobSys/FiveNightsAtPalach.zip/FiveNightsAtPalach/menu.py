import pygame
import sys
import random

pygame.init()

# ================== WINDOW ==================
WIDTH, HEIGHT = 1920, 1080
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Five Night's at Palach")
clock = pygame.time.Clock()

# ================== COLORS ==================
RED = (200, 30, 30)
DARK_RED = (120, 20, 20)
BLACK = (0, 0, 0)
GRAY = (60, 60, 60)
DARK_GRAY = (40, 40, 40)

# ================== FONTS ==================
title_font = pygame.font.SysFont("arialblack", 80)
menu_font = pygame.font.SysFont("arial", 48)
night_font = pygame.font.SysFont("arialblack", 56)
gallery_font = pygame.font.SysFont("arial", 26)

# ================== SCENE ==================
current_scene = "menu"

# ================== MENU ==================
menu_items = ["New Game", "Continue", "Gallery", "Exit"]
menu_rects = []

# ================== NIGHT SELECT ==================
nights = ["Night 1", "Night 2", "Night 3", "Night 4", "Night 5"]
night_rects = []
back_rect = None

# ================== BACKGROUNDS ==================
menu_bg = pygame.image.load("Untitled2.png").convert()
menu_bg = pygame.transform.scale(menu_bg, (WIDTH, HEIGHT))

night_bg = pygame.image.load("Untitled.png").convert()
night_bg = pygame.transform.scale(night_bg, (WIDTH, HEIGHT))

# ================== NEWSPAPER ==================
newspaper_img = pygame.image.load("newspaper.png").convert()
newspaper_img = pygame.transform.scale(newspaper_img, (WIDTH, HEIGHT))

current_scene = "menu"
newspaper_start_time = None

# ================== EFFECTS ==================
def draw_flicker():
    flicker = random.randint(0, 20)
    overlay = pygame.Surface((WIDTH, HEIGHT))
    overlay.set_alpha(flicker)
    overlay.fill(BLACK)
    screen.blit(overlay, (0, 0))


# ================== ACTIONS ==================
def activate_menu_item(index):
    global current_scene

    if menu_items[index] == "Exit":
        pygame.quit()
        sys.exit()

    elif menu_items[index] == "New Game":
        current_scene = "night_select"

    elif menu_items[index] == "Gallery":
        current_scene = "gallery"
# ================== DRAW NEWSPAPER ==================
def draw_newspaper():
    global current_scene, newspaper_start_time

    # Překreslí celou obrazovku newspaperem
    screen.blit(newspaper_img, (0, 0))

    # Po 5 sekundách zpět do menu
    if pygame.time.get_ticks() - newspaper_start_time >= 5000:
        current_scene = "menu"


# ================== DRAW MENU ==================
def draw_menu():
    screen.blit(menu_bg, (0, 0))

    title = title_font.render("Five Night's at Palach", True, RED)
    screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 80))

    menu_rects.clear()
    mouse_pos = pygame.mouse.get_pos()

    total_height = len(menu_items) * 70
    start_y = HEIGHT // 2 - total_height // 2
    menu_x = WIDTH * 0.25

    for i, item in enumerate(menu_items):
        text = menu_font.render(item, True, DARK_RED)
        rect = text.get_rect(midleft=(menu_x, start_y + i * 70))
        menu_rects.append(rect)

        if rect.collidepoint(mouse_pos):
            glow = pygame.Surface((rect.width + 30, rect.height + 15))
            glow.set_alpha(120)
            glow.fill(RED)
            screen.blit(glow, (rect.x - 15, rect.y - 7))
            text = menu_font.render(item, True, RED)

        screen.blit(text, rect)

    draw_flicker()


# ================== DRAW NIGHT SELECT ==================
def draw_night_select():
    global back_rect

    screen.blit(night_bg, (0, 0))

    # ČERVENÝ TITULEK
    title = title_font.render("Night Select", True, RED)
    screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 80))

    night_rects.clear()
    mouse_pos = pygame.mouse.get_pos()

    start_y = HEIGHT // 2 - 160
    night_x = 300  # můžeš posunout podle potřeby

    for i, night in enumerate(nights):
        text = night_font.render(night, True, RED)
        rect = text.get_rect(midleft=(night_x, start_y + i * 80))
        night_rects.append(rect)

        # ČERVENÝ HIGHLIGHT
        if rect.collidepoint(mouse_pos):
            glow = pygame.Surface((rect.width + 30, rect.height + 15))
            glow.set_alpha(120)
            glow.fill(DARK_RED)
            screen.blit(glow, (rect.x - 15, rect.y - 7))
            text = night_font.render(night, True, (255, 80, 80))  # světlejší červená

        screen.blit(text, rect)

    # BACK BUTTON
    back_text = menu_font.render("Back", True, RED)
    back_rect = back_text.get_rect(bottomright=(WIDTH - 80, HEIGHT - 60))

    if back_rect.collidepoint(mouse_pos):
        glow = pygame.Surface((back_rect.width + 30, back_rect.height + 15))
        glow.set_alpha(120)
        glow.fill(DARK_RED)
        screen.blit(glow, (back_rect.x - 15, back_rect.y - 7))
        back_text = menu_font.render("Back", True, (255, 80, 80))

    screen.blit(back_text, back_rect)

    draw_flicker()




# ================== DRAW GALLERY ==================
def draw_gallery():
    global back_rect

    screen.blit(menu_bg, (0, 0))

    title = title_font.render("Gallery", True, RED)
    screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 60))

    mouse_pos = pygame.mouse.get_pos()

    box_w, box_h = 700, 200
    start_x = WIDTH // 2 - box_w - 40
    start_y = 200
    gap = 40

    lorem = "Učitel Nenalezen"

    for row in range(2):
        for col in range(2):
            x = start_x + col * (box_w + gap)
            y = start_y + row * (box_h + gap)

            # box
            pygame.draw.rect(screen, DARK_GRAY, (x, y, box_w, box_h), border_radius=8)
            pygame.draw.rect(screen, GRAY, (x, y, box_w, box_h), 2, border_radius=8)

            # image placeholder
            img_rect = pygame.Rect(x + 15, y + 15, 170, 170)
            pygame.draw.rect(screen, BLACK, img_rect)

            # text
            text = gallery_font.render(lorem, True, RED)
            screen.blit(text, (img_rect.right + 20, y + 40))

    # Back
    back_text = menu_font.render("Back", True, RED)
    back_rect = back_text.get_rect(bottomright=(WIDTH - 80, HEIGHT - 60))
    screen.blit(back_text, back_rect)

    draw_flicker()


# ================== MAIN LOOP ==================
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:

            if current_scene == "menu":
                for i, rect in enumerate(menu_rects):
                    if rect.collidepoint(event.pos):
                        activate_menu_item(i)

            elif current_scene == "night_select":
                # Kliknutí na Back
                if back_rect and back_rect.collidepoint(event.pos):
                    current_scene = "menu"

                # Kliknutí na jednotlivé noci
                for rect in night_rects:
                    if rect.collidepoint(event.pos):
                        current_scene = "newspaper"
                        newspaper_start_time = pygame.time.get_ticks()


            elif current_scene == "gallery":
                if back_rect and back_rect.collidepoint(event.pos):
                    current_scene = "menu"

            

    if current_scene == "menu":
        draw_menu()
    elif current_scene == "night_select":
        draw_night_select()
    elif current_scene == "gallery":
        draw_gallery()
    elif current_scene == "newspaper":
        draw_newspaper()

 
    pygame.display.flip()
    clock.tick(60)
